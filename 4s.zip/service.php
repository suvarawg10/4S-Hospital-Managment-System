<html>
<head>
	<title> 4S Hospital </title>
	
	<link href="css/style.css" type="text/css" rel="stylesheet">
	
</head>
<body>
	
	<div class="top">
		<div>
		 Contact Us +91 9967571224 / +0251-244 3646| 4S@hospital.com 
		</div>
	</div>
	
	<div class="logo">
		<div>
			<table>
				<tr>
					<td width="600px" style="font-size:50px;font-family:forte;"> <font color="#428bca"> 4S </font><font color="#000"> Hospital</font> </td>
					<td> <br> <br>
						<font size="4px"> 
							<a href="index.php">HOME</a> 
							<a href="about.php">ABOUT US</a>  
							<a href="service.php">SERVICE</a>
							<a href="doctor.php">DOCTORS</a> 
							<a href="contact.php">CONTACT US</a>
						</font>
					</td>
				</tr>
			</table>
		</div>
	</div>
	
	
	
	<div class="bottom">
		<div>
			<table border="0">
				<tr>
					<td width="700px">
						<font color="#000"> OUR OUTSTANDING SERVICES</font> <br> <br>

					<font color="#000" size="6px"> What We Offer! </font> <br> <br>

					
					<ul>
					<li> DENTAL IMPLANTS
					<li> WHITENING
					<li> VACCINATIONS
					<li> LABORATORY
					<li> MEDICAL DRESSAGE
					<li> 24/7 PHARMACY
					</ul>
 <br><br>

<br>
 </td>
					
					
					<td style="padding-left:20px;"> <img src="img/01.jpg" width="400px"></td>
				</tr>
			
				
			</table>
		</div>
	</div>
	
	<div class="bottom">
		<div>
			<table border="0">
				<tr>
					<td width="700px">
						<font color="#000">------------ </font> <br> <br>

					<font color="#000" size="6px"> Our Department </font> <br> <br>

					<ul>
					<li> DENTAL CARE
					<li> CARDIAC
					<li> GYNAECOLOGIST
					<li> ORTHOPEDICS
					<li> GASTROENTEROLOGY
					<li> OUTPATIENT
					<li> MENTAL HEALTH
					</ul>


<br>
 </td>
					
					
					<td style="padding-left:20px;"> </td>
				</tr>
			
				
			</table>
		</div>
	</div>
	
	
	<div class="nav_down">
		<div>
		 &copy; 4S Hospital: THANE WEST
		</div>
	</div>
	
